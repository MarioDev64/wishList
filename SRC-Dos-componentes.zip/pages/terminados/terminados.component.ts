import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-terminados',
  templateUrl: 'terminados.component.html',
})
export class TerminadosComponent implements OnInit {
  constructor() {  }

  ngOnInit() {}
}
